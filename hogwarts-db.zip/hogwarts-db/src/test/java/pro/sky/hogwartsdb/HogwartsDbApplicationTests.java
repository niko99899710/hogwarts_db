package pro.sky.hogwartsdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HogwartsDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
