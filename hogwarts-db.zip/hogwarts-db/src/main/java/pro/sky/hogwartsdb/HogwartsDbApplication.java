package pro.sky.hogwartsdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HogwartsDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(HogwartsDbApplication.class, args);
	}

}
